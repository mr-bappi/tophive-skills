# LITTLE FERN — validation record

Date: 25 October 2026. Browser: cloud Chromium. Static HTML/CSS/JS, no build dependencies.

## PASS — actually exercised

- The page loads in the browser. Desktop and narrow-screen compositions visually inspected.
- Six responsive iframe viewport widths: 360, 390, 768, 1024, 1440, 1920 CSS px. No horizontal document overflow. The browser's scrollbar consumes 15px, giving document client widths 345, 375, 753, 1009, 1425, 1905 respectively. These are real browser frames, not physical-device tests.
- Main heading sizes measured in those frames: 41, 41, 67.584, 53, 73, 76px respectively; no headline clipping seen in inspected desktop/mobile views.
- Mobile menu opens, closes, and links navigate to the actual sections.
- Space filter hides Nature and Everyday Science and retains only Space. All category controls share the same filtering implementation.
- Plant click updates its pressed state and feedback. Observed plant transform changes from identity to scale(1.09), with the new leaf opacity changing to 1. This is deliberately labeled accelerated illustration rather than real plant growth.
- Nature lesson: introduction, incorrect answer feedback, retry, correct answer feedback, mission and completion.
- Space and Everyday Science lessons: correct-answer feedback, mission and completion via keyboard.
- Mission CTA is hidden until the correct answer; disabled quiz answers cannot be changed after success.
- Walking-water checklist: initially disabled start; all five items enable start; full experiment instructions display and close correctly.
- Save Space discovery, reload, observe saved state still active. The page catches unavailable-storage and malformed-data cases; those error paths were source-reviewed, not browser fault-injected.
- Dialog Tab and Shift+Tab loop, Escape closes, focus returns to the initiating control. A keyboard focus escape observed during QA was repaired with an explicit loop and retested.
- Grown-up accordion toggles from closed to open using Enter.
- Browser logs: no warning/error entries originating from the local page. The browser extension emitted unrelated metadata errors; these were excluded from page runtime results.
- Card footers align after repair: all three measured at the same vertical coordinate in the desktop browser.
- Local asset references, internal anchor targets, and unique static IDs checked with Python HTMLParser.
- `node --check dist/app.js` succeeds.
- Primary text/background contrast calculated using WCAG relative luminance: ink/paper 10.98:1, muted/paper 6.06:1, ink/sage 10.00:1, light/ink 11.33:1, ink/experiment-yellow 9.25:1, ink/button-yellow 8.07:1. This is a selected-palette check, not a complete automated accessibility audit.

## Repairs made during review

- Enforced HTML hidden state so button display styles cannot expose the next lesson step early.
- Removed an unsupported registered-trademark symbol from the fictional wordmark.
- Moved the mobile scene annotation below the field-note label.
- Aligned card footers using a shared flex layout.
- Added explicit modal focus wrapping and focus transfer after a successful answer.

## NOT TESTED / limitations

- Safari, Firefox, physical mobile hardware, touch-device automation, screen-reader software, and 200% browser zoom.
- OS-level reduced-motion emulation: CSS suppression is implemented and source-reviewed, but actual media-preference switching was unavailable through the browser API.
- FPS/performance instrumentation, network throttling, formal accessibility certification, and user testing with children.
- Independent comparison with the other brand demos: their current rendered artifacts were not inspected. No claim of legal or universal originality is made.
- The skill runtime exposes the installed skill and its references but no separate package version metadata was located; the user's stated v1.5.0 was not independently certified.

The new demo is isolated; no pre-existing production website was changed. The included responsive QA harness is only test equipment and is excluded from the published website and portable source archive.
