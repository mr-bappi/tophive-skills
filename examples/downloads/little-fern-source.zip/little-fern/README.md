# LITTLE FERN

A complete, buildless HTML/CSS/JavaScript website for a fictional science learning platform for children aged 7–11. Created using the installed Web & UI Design workflow: brief, direction, architecture, implementation, browser inspection, repairs, and delivery.

## Example user prompt

“I’m launching Little Fern, a small science learning project for children aged 7–11 and the grown-ups who explore with them. Make a welcoming website that gets a child doing something curious right away. Include nature, space, and everyday science; a short lesson they can actually finish; and a safe experiment using things at home. It should work on a parent’s phone and a family laptop, without asking a child to register. Choose the identity and build the whole experience.”

## Run

Open `dist/index.html`, or serve the `dist` folder with any static web server. For example, from this folder:

```sh
python3 -m http.server 8080 --directory dist
```

Then open http://localhost:8080. No install or compilation is required. Upload the contents of `dist` to a static host to publish independently.

## What works

- Responsive navigation and real section links.
- Interactive sunlight/plant illustration with explanatory feedback.
- Nature, space, and everyday-science adventure filters.
- Three complete sample lessons: introduction, question with retry feedback, and an outdoor/home mission.
- Browser-local saved discoveries, with graceful fallback when storage is unavailable.
- A walking-water experiment with a supplies checklist, adult-supervision notice, gated start, and full instructions.
- Accessible native dialog, explicit keyboard focus loop, Escape close, and focus restoration.
- Expandable information for grown-ups.
- Reduced-motion stylesheet and lightweight state transitions.

## Creative direction

A science discovery journal: fern-colored ink, warm paper, sunny yellow, terracotta, moonlit slate, and purpose-drawn SVG scenes. The plant interaction introduces a scientific mechanism before asking the visitor to read about the platform. Rounded-edge local sans-serif typography keeps the main content friendly; a small amount of italic Georgia supplies handwritten-note character. The layout alternates a field-note scene, browseable adventures, a kitchen-table experiment, parent guidance, and a final invitation.

The illustrations are original code-native SVG assets embedded in the HTML. No external fonts, photos, libraries, or trackers are requested by the page. Typography uses system fonts, so its exact appearance varies across operating systems.

## Content and scope

LITTLE FERN is fictional. There are no claimed customers, reviews, partnerships, performance metrics, or curriculum certifications. Lesson time labels are suggested activity lengths, not measured learning outcomes. No backend, accounts, payments, email delivery, or assessed curriculum is included. Saved items belong to the current browser only. Science activities require the adult guidance stated in the activity. This demonstration was not tested with children or reviewed as a formal educational curriculum.

See `QA.md` for actual checks and remaining test limits.
