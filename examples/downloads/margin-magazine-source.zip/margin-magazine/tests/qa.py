from pathlib import Path
import base64
from playwright.sync_api import sync_playwright
import json, sys

ROOT=Path(__file__).resolve().parents[1]
HTML=(ROOT/'index.html').read_text()
HTML=HTML.replace('<link rel="stylesheet" href="styles.css">', '<style>'+ (ROOT/'styles.css').read_text() + '</style>')
HTML=HTML.replace('<script src="script.js" defer></script>', '')
HTML=HTML.replace('</body>', '<script>'+ (ROOT/'script.js').read_text() + '</script></body>')
for img in (ROOT/'assets').glob('*.svg'):
  HTML=HTML.replace('assets/'+img.name, 'data:image/svg+xml;base64,'+base64.b64encode(img.read_bytes()).decode('ascii'))
reports=[]
errors=[]
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-gpu','--no-proxy-server'],timeout=18000)
 for width in [360,390,768,1024,1440,1920]:
  page=browser.new_page(viewport={'width':width,'height':900},device_scale_factor=1)
  page.on('pageerror',lambda err,w=width:errors.append(f'{w}: {err}'))
  page.set_content(HTML,wait_until='domcontentloaded',timeout=15000)
  page.evaluate("document.querySelectorAll('img').forEach(i=>i.loading='eager')")
  page.wait_for_timeout(650)
  page.evaluate('document.querySelectorAll(".reveal").forEach(e=>e.classList.add("in-view"))')
  metrics=page.evaluate('''() => ({
    width:innerWidth, scrollWidth:document.documentElement.scrollWidth,
    bodyWidth:document.body.scrollWidth, height:document.documentElement.scrollHeight,
    imgOk:[...document.querySelectorAll('img')].every(i=>i.complete&&i.naturalWidth>0),
    h1:getComputedStyle(document.querySelector('h1')).fontSize,
    visibleCards:[...document.querySelectorAll('.story-card')].filter(e=>!e.hidden).length,
    navMobile:getComputedStyle(document.querySelector('.menu-toggle')).display !== 'none'
  })''')
  if width <= 390:
   offenders=page.evaluate("""() => [...document.querySelectorAll('body *')].map(e=>({el:e.tagName.toLowerCase()+(e.className && typeof e.className==='string'?'.'+e.className.replaceAll(' ','.'):''), x:Math.round(e.getBoundingClientRect().x), right:Math.round(e.getBoundingClientRect().right), scroll:e.scrollWidth})).filter(x=>x.right>innerWidth+2 || x.x < -2).slice(0,18)""")
   print('OVERFLOW OFFENDERS', width, offenders)
  outfile=ROOT/'tests'/f'viewport-{width}.png'
  page.screenshot(path=str(outfile),full_page=True,animations='disabled')
  passed=metrics['scrollWidth']<=width and metrics['bodyWidth']<=width and metrics['imgOk'] and metrics['visibleCards']==4
  print(f"WIDTH {width}: {'PASS' if passed else 'FAIL'} | doc={metrics['scrollWidth']}px body={metrics['bodyWidth']}px image={metrics['imgOk']} height={metrics['height']}px h1={metrics['h1']} mobileNav={metrics['navMobile']}",flush=True)
  reports.append({'width':width,'pass':passed,**metrics,'screenshot':str(outfile)})
  if width == 390:
   assert page.locator('.menu-toggle').is_visible()
   page.locator('.menu-toggle').click()
   assert page.locator('#mobile-nav').is_visible()
   assert page.locator('.menu-toggle').get_attribute('aria-expanded') == 'true'
   page.locator('#mobile-nav a[href="#issue"]').click()
   assert page.locator('#mobile-nav').is_hidden()
   print('MOBILE MENU: PASS')
  if width == 1440:
   page.locator('[data-filter="poetry"]').click()
   assert page.locator('.story-card:visible').count()==1
   assert page.locator('#filter-count').inner_text()=='Showing 1 poetry piece'
   assert page.locator('[data-filter="poetry"]').get_attribute('aria-pressed')=='true'
   page.locator('[data-filter="all"]').click()
   assert page.locator('.story-card:visible').count()==4
   print('CATEGORY FILTERS: PASS')
   page.locator('.story-title-link[data-story="city"]').click()
   assert page.locator('#reading-dialog').is_visible()
   assert page.locator('#reader-title').inner_text() == 'When the city forgets your name'
   page.keyboard.press('Escape')
   assert page.locator('#reading-dialog').is_hidden()
   print('READING MODAL + ESC: PASS')
   page.locator('#submission-info').click()
   assert page.locator('#submissions-dialog').is_visible()
   page.locator('#submissions-done').click()
   assert page.locator('#submissions-dialog').is_hidden()
   print('SUBMISSION PREVIEW: PASS')
   page.locator('#newsletter-form button').click()
   assert 'valid email' in page.locator('#newsletter-feedback').inner_text()
   page.locator('#email').fill('demo@example.com')
   page.locator('#newsletter-form button').click()
   assert 'no email was sent or stored' in page.locator('#newsletter-feedback').inner_text()
   print('NEWSLETTER VALIDATION + DEMO MESSAGE: PASS')
  page.close()
 page=browser.new_page(viewport={'width':390,'height':844},reduced_motion='reduce')
 page.set_content(HTML,wait_until='domcontentloaded')
 assert page.evaluate('matchMedia("(prefers-reduced-motion: reduce)").matches')
 assert page.locator('.hero h1').is_visible()
 print('REDUCED MOTION: PASS')
 page.close()
 kb=browser.new_page(viewport={'width':1440,'height':900})
 kb.set_content(HTML,wait_until='domcontentloaded')
 kb.keyboard.press('Tab')
 assert kb.evaluate('document.activeElement.classList.contains("skip-link")')
 assert kb.evaluate('getComputedStyle(document.activeElement).outlineStyle') != 'none'
 print('KEYBOARD SKIP LINK + VISIBLE FOCUS: PASS')
 kb.close()
 nojs=browser.new_context(java_script_enabled=False,viewport={'width':390,'height':844})
 npage=nojs.new_page()
 npage.set_content(HTML,wait_until='domcontentloaded')
 assert npage.locator('#mobile-nav').is_visible()
 assert npage.locator('.hero h1').is_visible()
 print('NO-JS MOBILE NAV FALLBACK: PASS')
 nojs.close()
 browser.close()
print('PAGE ERRORS:',json.dumps(errors))
print('TOTAL RESULT:',sum(x['pass'] for x in reports),'/',len(reports),'responsive widths PASS')
(ROOT/'tests'/'results.json').write_text(json.dumps({'reports':reports,'jsErrors':errors},indent=2))
if errors or not all(x['pass'] for x in reports):sys.exit(1)
