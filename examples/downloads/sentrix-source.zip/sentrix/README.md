# SENTRIX — responsive cybersecurity website prototype

An original fictional brand and fully standalone HTML/CSS/JavaScript website created against the **Web & UI Design v1.5 source workflow** in TOPHIVE Design Lab. This is an isolated output; the design-lab source and all live websites were left untouched.

## Run

Open `index.html` directly, or from this directory:

```bash
python3 -m http.server 8765
```

Open http://localhost:8765. No build step, dependencies, tracking scripts, external images, or external fonts.

## Interactions

- Navigation and mobile menu, with Escape dismissal and visible focus.
- Incident console with three working illustrative scenarios, accessible arrow-key tabs, event timelines, local response-brief notes and reset controls.
- FAQ disclosures using native `<details>`.
- Concept-brief local `.txt` download including the optionally selected incident note.
- Reduced-motion styles and responsive layout.

## Scope and truthfulness

SENTRIX is fictional. All incidents and UI data are simulated. Nothing contacts a security provider or modifies infrastructure. No fabricated customers, integrations, partners, performance claims, testimonials, certifications, prices, or production support. Not a real security product. No backend, accounts, forms collecting personal data, or contact addresses.

## Design direction

**Incident command:** an evidence-first visual language that balances charcoal operational canvases with warm mineral reading surfaces and one alert-accent copper/signal tone. Platform-neutral UI typography plus compact monospace event metadata. No stock hacking imagery; the live frontend incident trace is the hero image. Responsive layout uses asymmetric editorial narrative transitioning into dense operational interfaces.

## Testing

See `qa/TEST-RESULTS.md` and screenshots after the validation run. Automated checks supplement, but do not replace, a production accessibility/security audit.
