# SENTRIX — actual verification record

**Date:** 2026-10-25 (UTC)  
**Artifact:** standalone `index.html`, `styles.css`, `app.js`, `assets/favicon.svg`  
**Browsers tested:** headless Chromium via Playwright Python (Chromium 144.0.7559.96 installed in the test container). No production browsers or backend were involved.

## Important test-environment qualification

The test container enforces a Chromium administrator URL blocklist (`URLBlocklist: ["*"]`). Direct browser navigation to both `http://127.0.0.1:8765/` and the local `file://` page fails with `ERR_BLOCKED_BY_ADMINISTRATOR` independently of site code. To validate visual layout and the working JavaScript interactions, Playwright used `page.set_content()` with the exact on-disk HTML, CSS, and JavaScript inlined in the equivalent DOM. This is a **real Chromium render/interaction test**, but **direct URL navigation was NOT TESTED successfully in Chromium**. Separately, the local HTTP server returned HTTP 200 for `/`, `/styles.css`, `/app.js` and `/assets/favicon.svg` using `curl`.

## Test outcomes

| Gate | Result | Evidence |
|---|---|---|
| JavaScript syntax | PASS | `node --check app.js` exit 0 |
| Static server asset resolution | PASS | Four local `curl` requests returned HTTP 200 |
| 360px mobile width | PASS | Browser render; document/body horizontal overflow 0px |
| 390px mobile width | PASS | Browser render; document/body horizontal overflow 0px |
| 768px tablet width | PASS | Browser render; document/body horizontal overflow 0px |
| 1024px small desktop | PASS | Browser render; document/body horizontal overflow 0px |
| 1440px desktop | PASS | Browser render; document/body horizontal overflow 0px |
| 1920px wide desktop | PASS | Browser render; document/body horizontal overflow 0px |
| Responsive navigation | PASS | Mobile open, Escape close, link close; desktop nav visible |
| Accessible scenario tabs | PASS | Click and ArrowRight selection update scenario and ARIA state |
| Event and assessment states | PASS | Scenario title, priority, event sequence and next action update |
| Local response notes | PASS | Add disables button and updates status; Reset restores it |
| FAQ disclosure | PASS | Native `<details>` opens |
| Brief download | PASS | Browser downloaded `sentrix-concept-brief.txt` with correct heading |
| Reduced-motion preference | PASS | Continuous SVG animation disabled; content fully visible |
| Regular motion | PASS | Animated trace dash offset changes over time; scroll-reveal becomes visible |
| Browser script errors | PASS | No page exceptions observed during the recorded checks |
| Internal navigation targets | PASS | All five tested section IDs exist |
| External resources | PASS | No external `<a href="http...">` destinations; page does not require externally hosted fonts/images/libraries |
| Full production security assessment | NOT TESTED | No backend/auth/integrations; this is a concept site |
| Cross-browser Safari/Firefox | NOT TESTED | Chrome-family Chromium only |
| Screen reader / assistive technology audit | NOT TESTED | Semantic and keyboard checks only; no real AT session |
| Device-hardware performance | NOT TESTED | Screenshots/emulation are not physical phone tests |
| Direct Chrome URL navigation | NOT TESTED | Blocked by the test environment's central browser policy |

## Visual review

Manually inspected captured 1440px and 390px hero views, console views and workflow/closing layouts. Verified the grid and navigation reflow, title wrapping, card boundaries, visible console controls and readable mobile sequence. Reduced-contrast secondary large-text and metadata colors were adjusted before rerunning the checks. No known clipping or unintended horizontal overflow was observed in these captures.

## Caveats and boundaries

- The illustrated event trace and all console scenarios use local fabricated **demo events**, not fabricated product statistics.
- No actual threats are monitored or incidents resolved; none of the site's interactions call a backend.
- No real brands, customer logos, partnerships, security certifications, testimonials, or performance metrics are asserted.
- No Git commit, deployment or production-file modifications were performed.

`qa/check.py` contains the reproducible Playwright script and `qa/results.json` contains the last execution results.
