from playwright.sync_api import sync_playwright
from pathlib import Path
import json

root=Path(__file__).resolve().parent
html=(root.parent/'index.html').read_text()
css=(root.parent/'styles.css').read_text()
js=(root.parent/'app.js').read_text()
html=html.replace('<link rel="stylesheet" href="styles.css">','<style>'+css+'</style>').replace('<script src="app.js" defer></script>','').replace('</body>','<script>'+js+'</script></body>')
results={'viewports':[],'functional':{},'errors':[],'failures':[]}
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    for width in [360,390,768,1024,1440,1920]:
        page=browser.new_page(viewport={'width':width,'height':900},device_scale_factor=1,reduced_motion='reduce')
        page.on('pageerror',lambda e:results['errors'].append(str(e)))
        page.set_content(html,wait_until='load')
        response=None
        page.screenshot(path=str(root/f'sentrix-{width}.png'),full_page=True,animations='disabled')
        if width in (390,1440): page.screenshot(path=str(root/f'sentrix-{width}-viewport.png'),animations='disabled')
        metrics=page.evaluate('''() => ({doc:document.documentElement.scrollWidth, body:document.body.scrollWidth, inner:innerWidth, h:document.documentElement.scrollHeight, headings:[...document.querySelectorAll('h1')].map(h=>h.innerText), navVisible: getComputedStyle(document.querySelector('.mobile-toggle')).display!=='none', font:getComputedStyle(document.querySelector('h1')).fontFamily})''')
        item={'width':width,'render':'inline DOM (managed-browser URL policy)','overflow':metrics['doc']-width,'body_overflow':metrics['body']-width,'height':metrics['h'],'title':metrics['headings'][0],'menu':metrics['navVisible'],'font':metrics['font']}
        results['viewports'].append(item)
        if item['overflow']>1 or item['body_overflow']>1:
            results['failures'].append('bad viewport: '+str(item))
        page.close()
    page=browser.new_page(viewport={'width':390,'height':844},accept_downloads=True)
    page.set_content(html,wait_until='load')
    menu=page.locator('.mobile-toggle');menu.click()
    results['functional']['menu_opens']=menu.get_attribute('aria-expanded')=='true' and page.locator('#mobile-nav').is_visible()
    page.keyboard.press('Escape')
    results['functional']['menu_esc_closes']=menu.get_attribute('aria-expanded')=='false' and not page.locator('#mobile-nav').is_visible()
    menu.click();page.locator('#mobile-nav a[href="#platform"]').click()
    results['functional']['menu_link_closes']=menu.get_attribute('aria-expanded')=='false'
    page.locator('#tab-deploy').click()
    results['functional']['tab_switch_click']=page.locator('#scenario-title').inner_text()=='Unrecognized production deployment' and page.locator('#tab-deploy').get_attribute('aria-selected')=='true'
    page.locator('#tab-deploy').focus();page.keyboard.press('ArrowRight')
    results['functional']['tab_arrow_keys']=page.locator('#tab-access').get_attribute('aria-selected')=='true'
    page.locator('#add-note').click()
    results['functional']['note_saves_locally']=page.locator('#add-note').is_disabled() and 'NOTE ADDED' in page.locator('#brief-status').inner_text()
    page.locator('#reset-scenario').click()
    results['functional']['reset_restores']=not page.locator('#add-note').is_disabled()
    faq=page.locator('.faq details').first; faq.locator('summary').click()
    results['functional']['faq_expands']=faq.evaluate('(e)=>e.open')
    with page.expect_download() as d:page.locator('#download-brief').click()
    dl=d.value
    dest=root/'download-test.txt';dl.save_as(str(dest))
    results['functional']['download']=dl.suggested_filename=='sentrix-concept-brief.txt' and 'SENTRIX — PRODUCT CONCEPT BRIEF' in dest.read_text()
    page.close()
    reduced=browser.new_page(viewport={'width':390,'height':844},reduced_motion='reduce')
    reduced.set_content(html,wait_until='load')
    results['functional']['reduced_motion']=reduced.evaluate("getComputedStyle(document.querySelector('.closing-graphic svg')).animationName")=='none'
    results['functional']['no_reduced_invisible_reveal']=reduced.evaluate("getComputedStyle(document.querySelector('.workflow-intro')).opacity")=='1'
    reduced.close()
    desktop=browser.new_page(viewport={'width':1440,'height':900})
    desktop.set_content(html,wait_until='load')
    results['functional']['desktop_navigation']=desktop.locator('.desktop-nav').is_visible() and not desktop.locator('.mobile-toggle').is_visible()
    results['functional']['anchors_exist']=all(desktop.locator(f'#{s}').count()==1 for s in ['platform','workflow','console','principles','questions'])
    results['functional']['no_external_links']=desktop.locator('a[href^="http"]').count()==0
    desktop.close()
    animated=browser.new_page(viewport={'width':1440,'height':900},reduced_motion='no-preference')
    animated.set_content(html,wait_until='load')
    off1=animated.locator('.connector-line.highlighted').evaluate('(e)=>getComputedStyle(e).strokeDashoffset')
    animated.wait_for_timeout(300)
    off2=animated.locator('.connector-line.highlighted').evaluate('(e)=>getComputedStyle(e).strokeDashoffset')
    results['functional']['motion_is_running']=off1!=off2
    animated.locator('.workflow').scroll_into_view_if_needed()
    animated.wait_for_timeout(900)
    results['functional']['scroll_reveal']=animated.locator('.workflow-intro').evaluate('(e)=>getComputedStyle(e).opacity')=='1'
    animated.close();browser.close()
if results['errors']: results['failures'].append('page errors')
for k,v in results['functional'].items():
    if not v:results['failures'].append('functional: '+k)
(root/'results.json').write_text(json.dumps(results,indent=2))
print(json.dumps(results,indent=2))
raise SystemExit(1 if results['failures'] else 0)
